# Developing database applications  - Other languages Python, Node.js and unstructured data (JSON)

In this workshop, you will experience Oracle's JSON capabilities using both relational and document-store APIs. You will be learn all variants of how to leverage JSON in the Oracle database, starting from the native JSON datatype over JSON Collections and JSON Duality Views - the latest groundbreaking JSON-related functionality, to the Oracle Database API for MongoDB that provides full MongoDB compatibility in a plug-and-play fashion

This lab is organized into different topics, each topic consists of multiple steps. After completing this workshop a user has a very good understanding of what JSON features are available in Oracle Database and when to use them. You will work against the same data using both with SQL and using the MongoDB API and will experience yourself why Oracle database is better suited for JSON Development than Mongo database.

Objective
This workshop is not a 'cookbook' or 'design guideline' on how to work with JSON data - the purpose is to illustrate various JSON features that the Oracle Database offers. That said, you likely find that many examples are applicable to your business needs!

You can complete all Oracle-related parts of the workshop using your web browser. There is no need to install any extra software other than MongoDB Shell and MongoDB Command Line Database Tools when you're prompted to do so. (Optionally, you can install MongoDB Compass, too). When writing a real application, you would call many of the functionalities from a programming language like Java, JavaScript(nodeJS) or Python.

## Task 1: Click on the URL below to start the lab:
<a href="https://livelabs.oracle.com/pls/apex/r/dbpm/livelabs/run-workshop?p210_wid=3635&p210_wec=&session=105845842886606">Developing Database Applications - JSON</a>