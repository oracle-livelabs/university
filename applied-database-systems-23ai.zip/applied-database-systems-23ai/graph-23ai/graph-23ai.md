# Intro to Graph Database on Oracle

This workshop focuses on working with Property Graphs in Oracle Database 23ai Free. You will create a graph from two tables, one containing bank account information, and another containing bank transactions information. You will then run graph pattern queries in SQL on this graph. You will find circular payment chains, multi-hop paths between accounts, and more.

In Oracle Database 23ai Free - Developer Release the GRAPH_TABLE function and MATCH clause of the new SQL:2023 standard enable you to write simple SQL queries to follow connections in data. This workshop illustrates how you can model your data as a graph and run graph queries in SQL to quickly see relationships in your data that are difficult to identify otherwise.

## Task 1: Click on the URL below to start the lab:
<a href="https://livelabs.oracle.com/pls/apex/r/dbpm/livelabs/view-workshop?wid=736">Intro to Graph Database on Oracle</a>
 