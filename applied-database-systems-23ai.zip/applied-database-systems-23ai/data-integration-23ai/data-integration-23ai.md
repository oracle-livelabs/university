# Data Integration

This workshop will walk you through the steps to create an end-to-end integration of reading a file from the File Server and inserting the data set in an Oracle Autonomous Date Warehouse(ADW) Table leveraging out of the box adapters.

We shall also talk about provisioning Oracle Integration 3 instance, enabling File Server, provisioning Oracle Autonomous Database but, all of these tasks are optional.

## Task 1: Click on the URL below to start the lab:
<a href="https://apexapps.oracle.com/pls/apex/r/dbpm/livelabs/run-workshop?p210_wid=3430">Data Integration</a>